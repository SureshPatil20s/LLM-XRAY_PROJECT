# Exportable Research Chat
*Exported on: 2026-11-06 22:49:45 UTC*
*Conversation ID: `4ce533b3-5702-4f67-ad81-d0301556261d`*

---

### User (2026-11-06T17:19:45.825471+00:00)
Summarize Newton's first law.

---

### Assistant (2026-11-06T17:19:45.836683+00:00)
An object at rest remains at rest unless acted upon by an external force.

**Referenced Document Sources:**
- 📄 `principia.pdf` (Page 1)

---
