# Exportable Research Chat
*Exported on: 2026-11-05 12:24:47 UTC*
*Conversation ID: `f8e1d5f7-51ce-4feb-93ad-7be90cab97d4`*

---

### User (2026-11-05T06:54:47.399185+00:00)
Summarize Newton's first law.

---

### Assistant (2026-11-05T06:54:47.449184+00:00)
An object at rest remains at rest unless acted upon by an external force.

**Referenced Document Sources:**
- 📄 `principia.pdf` (Page 1)

---
