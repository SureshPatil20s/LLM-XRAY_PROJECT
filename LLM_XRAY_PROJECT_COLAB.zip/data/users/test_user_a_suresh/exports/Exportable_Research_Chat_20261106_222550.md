# Exportable Research Chat
*Exported on: 2026-11-06 22:25:50 UTC*
*Conversation ID: `7b2d9c9f-22f8-493b-961f-9f36314cfa76`*

---

### User (2026-11-06T16:55:50.891330+00:00)
Summarize Newton's first law.

---

### Assistant (2026-11-06T16:55:50.905675+00:00)
An object at rest remains at rest unless acted upon by an external force.

**Referenced Document Sources:**
- 📄 `principia.pdf` (Page 1)

---
