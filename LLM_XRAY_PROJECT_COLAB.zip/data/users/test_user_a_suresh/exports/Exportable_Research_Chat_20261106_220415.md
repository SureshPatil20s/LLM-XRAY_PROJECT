# Exportable Research Chat
*Exported on: 2026-11-06 22:04:15 UTC*
*Conversation ID: `be17066c-bf24-4306-a21b-466b3707fdab`*

---

### User (2026-11-06T16:34:15.233529+00:00)
Summarize Newton's first law.

---

### Assistant (2026-11-06T16:34:15.244533+00:00)
An object at rest remains at rest unless acted upon by an external force.

**Referenced Document Sources:**
- 📄 `principia.pdf` (Page 1)

---
