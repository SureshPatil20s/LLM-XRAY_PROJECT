# Exportable Research Chat
*Exported on: 2026-11-06 22:12:38 UTC*
*Conversation ID: `0926ccfd-8927-4bd9-a418-b083c8c369ee`*

---

### User (2026-11-06T16:42:38.452630+00:00)
Summarize Newton's first law.

---

### Assistant (2026-11-06T16:42:38.462147+00:00)
An object at rest remains at rest unless acted upon by an external force.

**Referenced Document Sources:**
- 📄 `principia.pdf` (Page 1)

---
