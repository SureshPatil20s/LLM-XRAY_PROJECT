# Exportable Research Chat
*Exported on: 2026-11-06 22:45:10 UTC*
*Conversation ID: `176348d3-25e4-4703-98ea-9a5f8fcd9512`*

---

### User (2026-11-06T17:15:10.502994+00:00)
Summarize Newton's first law.

---

### Assistant (2026-11-06T17:15:10.519262+00:00)
An object at rest remains at rest unless acted upon by an external force.

**Referenced Document Sources:**
- 📄 `principia.pdf` (Page 1)

---
