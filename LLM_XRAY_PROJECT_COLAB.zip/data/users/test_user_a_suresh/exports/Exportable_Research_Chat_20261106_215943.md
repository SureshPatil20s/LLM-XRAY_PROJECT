# Exportable Research Chat
*Exported on: 2026-11-06 21:59:43 UTC*
*Conversation ID: `111fb863-16ac-4dcf-934a-b23db0e841de`*

---

### User (2026-11-06T16:29:43.054092+00:00)
Summarize Newton's first law.

---

### Assistant (2026-11-06T16:29:43.068493+00:00)
An object at rest remains at rest unless acted upon by an external force.

**Referenced Document Sources:**
- 📄 `principia.pdf` (Page 1)

---
