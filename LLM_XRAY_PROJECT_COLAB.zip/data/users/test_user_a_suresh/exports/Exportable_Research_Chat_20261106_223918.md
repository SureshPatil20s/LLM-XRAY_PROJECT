# Exportable Research Chat
*Exported on: 2026-11-06 22:39:18 UTC*
*Conversation ID: `5bd768de-721d-44d1-886c-c8eaa33ea1e4`*

---

### User (2026-11-06T17:09:17.983920+00:00)
Summarize Newton's first law.

---

### Assistant (2026-11-06T17:09:17.996150+00:00)
An object at rest remains at rest unless acted upon by an external force.

**Referenced Document Sources:**
- 📄 `principia.pdf` (Page 1)

---
