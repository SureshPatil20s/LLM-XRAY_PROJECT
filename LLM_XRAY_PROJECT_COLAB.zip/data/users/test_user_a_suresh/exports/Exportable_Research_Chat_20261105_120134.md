# Exportable Research Chat
*Exported on: 2026-11-05 12:01:34 UTC*
*Conversation ID: `61eb6d02-c176-45b5-92ba-29e4979048bc`*

---

### User (2026-11-05T06:31:34.309130+00:00)
Summarize Newton's first law.

---

### Assistant (2026-11-05T06:31:34.349584+00:00)
An object at rest remains at rest unless acted upon by an external force.

**Referenced Document Sources:**
- 📄 `principia.pdf` (Page 1)

---
